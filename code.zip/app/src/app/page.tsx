'use client'

/* eslint-disable react/no-unescaped-entities */
import { useState, useEffect } from 'react';
import { MdDeleteForever } from "react-icons/md";
import { FaPencilAlt } from "react-icons/fa";
import AnimatedBox from "@/components/AnimatedBox";
import Popup from '@/components/Popup';
import Link from 'next/link';

interface Record {
  id: number,
  first_name: string,
  last_name: string,
  email: string,
  gender: string
}

export default function Home() {
  const BASE_URL = "http://localhost:8080";

  // State for storing fetched data
  const [data, setData] = useState<Record[] | undefined>(undefined);

  // State for managing the popup
  const [popup, setPopup] = useState<{ show: boolean, type: 'delete' | 'update', id: number | null }>({ show: false, type: 'delete', id: null });

  // Function to fetch data
  const fetchData = async () => {
    try {
      const res = await fetch(`${BASE_URL}/items`);
      if (!res.ok) {
        throw new Error('Failed to fetch data');
      }
      const json = await res.json();
      setData(json);
    } catch (error) {
      console.error(error);
      setData(undefined);
    }
  };

  // Function to delete an entry
  const deleteItemAsync = async (rowId: number) => {
    await fetch(`${BASE_URL}/item/${rowId}`, {
      method: 'DELETE',
      headers: {
        'Content-Type': 'application/json',
      }
    });

    fetchData();
  };

  // Function to handle delete clicked
  const handleDeleteClicked = (rowId: number) => {
    setPopup({ show: true, type: 'delete', id: rowId });
  };

  // Function to handle update clicked (for future implementation)
  const handleUpdateClicked = (rowId: number) => {
    setPopup({ show: true, type: 'update', id: rowId });
  };

  // Function to handle confirm action in the popup
  const handleConfirm = async () => {
    if (popup.type === 'delete' && popup.id !== null) {
      await deleteItemAsync(popup.id);
    }

    setPopup({ show: false, type: 'delete', id: null });
  };

  // Function to handle cancel action in the popup
  const handleCancel = () => {
    setPopup({ show: false, type: 'delete', id: null });
  };

  // Close popup when ESC key is pressed
  useEffect(() => {
    const handleEscape = (event: KeyboardEvent) => {
      if (event.key === 'Escape') {
        handleCancel();
      }
    };

    document.addEventListener('keydown', handleEscape);

    return () => {
      document.removeEventListener('keydown', handleEscape);
    };
  }, []);

  // Use useEffect to fetch data on component mount
  useEffect(() => {
    fetchData();
  }, [setData]);

  return (
    <main className="flex min-h-screen w-full mx-auto flex-col items-center justify-between pt-24 pb-24 px-4 bg-dark font-lato overflow-hidden">

      {/* Max Width Wrapper */}
      <div className="max-w-screen-xl w-full">

        {/* Header */}
        <AnimatedBox>
          <div className="sm:h-48 flex flex-col items-center justify-start gap-2">
            <h1 className="md:text-5xl sm:text-4xl text-2xl font-semibold">Besedo Technical Test</h1>
            <p className="sm:text-2xl text-md font-light">Luke Formosa</p>
          </div>
        </AnimatedBox>

        <AnimatedBox>
          {/* Control Area */}
          <div className="pb-4 flex justify-center">
            <Link
              className="font-bold bg-white rounded-lg px-4 py-2 text-dark hover:scale-[1.05] duration-75"
              href={"/create"}
            >
              Create Entry
            </Link>
          </div>
        </AnimatedBox>

        {/* Table Container */}
        <div className="overflow-x-auto">
          <table id="data-table" className="mx-auto text-center animate-fade-in-up min-w-full">
            <thead>
              <tr className="bg-[#121212]">
                <th className="p-3">Id</th>
                <th className="p-3">Name</th>
                <th className="p-3">Surname</th>
                <th className="p-3">Email</th>
                <th className="p-3">Gender</th>
                <th className="p-3">Controls</th>
              </tr>
            </thead>
            <tbody>
              {data ? (
                data.map((row, index) => (
                  <tr key={index} className={index % 2 ? 'bg-darkHover hover:opacity-80' : 'bg-darkControl hover:opacity-80'}>
                    <td className="p-3">{row.id}</td>
                    <td className="p-3">{row.first_name}</td>
                    <td className="p-3">{row.last_name}</td>
                    <td className="p-3">{row.email}</td>
                    <td className="p-3">{row.gender}</td>
                    <td className='flex items-center justify-center'>
                      <div>
                        <button className='p-4' onClick={() => handleDeleteClicked(row.id)}>
                          <MdDeleteForever size={28} className='hover:scale-[1.1] fill-red-400' />
                        </button>
                      </div>
                      <Link href={`/update/${row.id}`} className='p-4'>
                        <FaPencilAlt size={24} className='mb-[0.1rem] hover:scale-[1.1] fill-blue-400' />
                      </Link>
                    </td>
                  </tr>
                ))
              ) : (
                <tr>
                  <td colSpan={6} className="p-3">Couldn't get data...</td>
                </tr>
              )}
            </tbody>
          </table>
        </div>

      </div>

      {/* Conditionally render the Popup component */}
      {popup.show && (
        <Popup
          message={`Are you sure you want to ${popup.type} this record?`}
          onConfirm={handleConfirm}
          onCancel={handleCancel}
        />
      )}

    </main>
  );
}
