'use client'

import Link from 'next/link';
import { useRouter, useSearchParams } from 'next/navigation';
import { useState, FormEvent, useEffect } from 'react';
import { IoMdArrowRoundBack } from "react-icons/io";
import Popup from '@/components/Popup'; // Adjust the import path as needed

interface CreateRecord {
    first_name: string;
    last_name: string;
    email: string;
    gender: string;
}

export default function Page() {
    const BASE_URL = "http://localhost:8080";
    const router = useRouter();
    const searchParams = useSearchParams();

    // State for managing the form data
    const [formData, setFormData] = useState<CreateRecord>({
        first_name: '',
        last_name: '',
        email: '',
        gender: ''
    });

    // State for controlling the popup visibility
    const [isPopupOpen, setIsPopupOpen] = useState(false);

    // Check if URL contains popup state and open popup if so
    useEffect(() => {
        if (searchParams.get('showPopup') === 'true') {
            setIsPopupOpen(true);
        }
    }, [searchParams]);

    // Function to create an entry
    const createEntryAsync = async (record: CreateRecord) => {
        await fetch(`${BASE_URL}/item`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify(record),
        });
        router.push("/");
    };

    // Function to handle confirm action in the popup
    const handleConfirm = async () => {
        await createEntryAsync(formData);
        setIsPopupOpen(false);
        // Reset URL parameter
        router.push('/');
    };

    // Function to handle cancel action in the popup
    const handleCancel = () => {
        setIsPopupOpen(false);
        // Reset URL parameter
        router.push('/');
    };

    async function onSubmit(event: FormEvent<HTMLFormElement>) {
        event.preventDefault();
        // Update URL to show popup
        router.push(`/create?showPopup=true`);
    }

    // Handle input change
    const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
        const { name, value } = e.target;
        setFormData({
            ...formData,
            [name]: value,
        });
    };

    return (
        <main className="min-h-screen min-w-screen bg-dark flex pb-12 justify-center pt-48">
            <div className='flex flex-col gap-12 items-center'>
                <div className='flex flex-col gap-4 items-center'>
                    <Link href="/" className='text-4xl'>
                        <IoMdArrowRoundBack size={60} className='hover:scale-[1.2] duration-100' />
                    </Link>
                    <h1 className='text-4xl font-bold'>Create Entry</h1>
                </div>
                <form onSubmit={onSubmit} className='flex flex-col sm:gap-4 gap-10 text-white'>
                    <div className='flex sm:flex-row flex-col gap-10'>
                        <div className='flex flex-1 flex-col items-start gap-1'>
                            <label htmlFor="first_name" className='text-gray-100 text-sm'>First Name</label>
                            <input
                                type="text"
                                name="first_name"
                                value={formData.first_name}
                                onChange={handleInputChange}
                                className='rounded-md p-2 bg-darkControl'
                            />
                        </div>
                        <div className='flex flex-1 flex-col items-start gap-1'>
                            <label htmlFor="last_name" className='text-gray-100 text-sm'>Last Name</label>
                            <input
                                type="text"
                                name="last_name"
                                value={formData.last_name}
                                onChange={handleInputChange}
                                className='rounded-md p-2 bg-darkControl'
                            />
                        </div>
                    </div>
                    <div className='flex sm:flex-row flex-col gap-10'>
                        <div className='flex flex-1 flex-col items-start gap-1'>
                            <label htmlFor="email" className='text-gray-100 text-sm'>Email</label>
                            <input
                                type="text"
                                name="email"
                                value={formData.email}
                                onChange={handleInputChange}
                                className='rounded-md p-2 bg-darkControl'
                            />
                        </div>
                        <div className='flex flex-1 flex-col items-start gap-1'>
                            <label htmlFor="gender" className='text-gray-100 text-sm'>Gender</label>
                            <input
                                type="text"
                                name="gender"
                                value={formData.gender}
                                onChange={handleInputChange}
                                className='rounded-md p-2 bg-darkControl'
                            />
                        </div>
                    </div>
                    <div className='flex items-center justify-center'>
                        <button type="submit" className='text-dark border rounded-lg py-3 px-8 mt-12 bg-white font-bold hover:opacity-85 duration-75'>Submit</button>
                    </div>
                </form>
            </div>

            {/* Conditionally render the Popup component */}
            {isPopupOpen && (
                <Popup
                    message="Are you sure you want to create this record?"
                    onConfirm={handleConfirm}
                    onCancel={handleCancel}
                />
            )}
        </main>
    );
}
