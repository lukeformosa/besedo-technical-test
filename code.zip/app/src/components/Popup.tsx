import React, { useEffect, useState } from 'react';
import { AiOutlineClose } from 'react-icons/ai';

interface PopupProps {
  message: string;
  onConfirm: () => void;
  onCancel: () => void;
}

export default function Popup({ message, onConfirm, onCancel }: PopupProps) {
  const [isVisible, setIsVisible] = useState(false);

  useEffect(() => {
    // Trigger the fade-in animation when the component mounts
    setIsVisible(true);

    // Disable body scrolling when the popup is visible
    document.body.style.overflow = 'hidden';

    return () => {
      // Re-enable body scrolling when the popup is hidden
      document.body.style.overflow = '';
    };
  }, []);

  const handleClose = () => {
    // Trigger the fade-out animation
    setIsVisible(false);

    // Wait for the animation to complete before calling the onCancel function
    setTimeout(() => {
      onCancel();
    }, 300); // Match this duration with the CSS transition duration
  };

  // Handle closing the popup by clicking outside
  const handleClickOutside = (event: MouseEvent) => {
    const popupElement = document.getElementById('popup-box');
    if (popupElement && !popupElement.contains(event.target as Node)) {
      handleClose();
    }
  };

  useEffect(() => {
    // Add event listener for clicks outside the popup
    document.addEventListener('mousedown', handleClickOutside);

    return () => {
      // Clean up event listener on unmount
      document.removeEventListener('mousedown', handleClickOutside);
    };
  }, []);

  return (
    <div
      className={`fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 transition-opacity duration-300 ${
        isVisible ? 'opacity-100' : 'opacity-0'
      }`}
    >
      <div
        id="popup-box"
        className={`bg-white rounded-lg p-6 text-center max-w-sm relative transform transition-transform duration-300 ${
          isVisible ? 'scale-100' : 'scale-95'
        }`}
      >
        {/* Close button */}
        <button className="absolute top-2 right-2 text-gray-500 hover:text-gray-700" onClick={handleClose}>
          <AiOutlineClose size={24} />
        </button>
        <p className="mb-4 text-lg text-dark">{message}</p>
        <div className="flex justify-around">
          <button
            className="bg-blue-500 text-white px-4 py-2 rounded hover:bg-blue-600"
            onClick={onConfirm}
          >
            Confirm
          </button>
        </div>
      </div>
    </div>
  );
}
