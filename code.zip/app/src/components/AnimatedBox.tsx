'use client'

import React, { ReactNode } from 'react';
import { useInView } from 'react-intersection-observer';

interface AnimatedBoxProps {
    children: ReactNode
}

const AnimatedBox: React.FC<AnimatedBoxProps> = ({ children }) => {
    const { ref, inView } = useInView({
        triggerOnce: true,
        threshold: 0.2,
    });

    return (
        <div
            ref={ref}
            className={`transition-opacity duration-500 ease-out transform ${inView ? 'animate-fade-in-up' : 'opacity-0'
                }`}
        >
            {children}
        </div>
    );
};

export default AnimatedBox;
