const express = require("express");
const bodyParser = require("body-parser");
const fs = require("fs");
var cors = require("cors");
const { check, validationResult } = require("express-validator");

const app = express();
const PORT = 8080;

app.use(bodyParser.json());
app.use(cors());

let items = [];

const createSchemaValidation = [
  check("first_name").isString().withMessage("first_name must be a string"),
  check("last_name").isString().withMessage("last_name must be a string"),
  check("email").isEmail().withMessage("email must be a valid email"),
  check("gender").isString().withMessage("gender must be a string"),
];

//LOAD DUMMY DATA
const populateItems = () => {
  try {
    const data = fs.readFileSync("dummy_data.json", "utf8");
    items = JSON.parse(data);
  } catch (e) {
    console.error("Data failed to load with error: ", e);
  }
};

populateItems();

// CREATE
app.post("/item", createSchemaValidation, (req, res) => {
  const errors = validationResult(req);
  if (!errors.isEmpty()) {
    return res.status(400).json({ errors: errors.array() });
  }

  const item = req.body;
  item.id = items.length + 1;
  items.push(item);
  res.status(201).json(item);
});

// READ ALL
app.get("/items", (req, res) => {
  res.json(items);
});

// Read ONE
app.get("/item/:id", (req, res) => {
  const id = parseInt(req.params.id, 10);
  const item = items.find((item) => item.id === id);
  if (item) {
    res.json(item);
  } else {
    res.status(404).json({ message: "Item not found" });
  }
});

// UPDATE
app.put("/item/:id", (req, res) => {
  const id = parseInt(req.params.id, 10);
  const index = items.findIndex((item) => item.id === id);
  if (index !== -1) {
    items[index] = req.body;
    res.json(items[index]);
  } else {
    res.status(404).json({ message: "Item not found" });
  }
});

// DELETE
app.delete("/item/:id", (req, res) => {
  const id = parseInt(req.params.id, 10);
  items = items.filter((item) => item.id !== id);
  res.status(204).send();
});

app.listen(PORT, () => {
  console.log(`Server listening on port ${PORT}`);
});
